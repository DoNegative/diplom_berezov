export interface SidebarCollapseItemInterface {
    text: string
    path: string
}