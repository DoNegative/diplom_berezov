export interface NavLinkInterface {
    text: string
    path: string
    icon?: any
}