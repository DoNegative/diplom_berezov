import React, { useState, useEffect, Component } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";
import EditClients from "./EditClients";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
export default function Td(props) {
  useEffect(() => {}, []);
  const [modalWindowEdit, setModalWindowEdit] = useState(false);
  function deleteClient(id) {
    APIs.deleteClient(id).then((response) => {
      props.getClients();
    });
  }
  return (
    <tr>
      <td>{props.tr.fio}</td>

      <td>{props.tr.phone_number}</td>
      <td>{props.tr.email}</td>
      <td style={{ textAlign: "center", width: "10%" }}>
        <EditOutlined
          style={{ marginRight: "8px" }}
          onClick={() => setModalWindowEdit(true)}
        />{" "}
        <DeleteOutlined onClick={() => deleteClient(props.tr.id)} />
        <ModalWindow active={modalWindowEdit} setActive={setModalWindowEdit}>
          <EditClients
            setActive={setModalWindowEdit}
            id={props.tr.id}
            update={props.getClients}
          ></EditClients>
        </ModalWindow>
      </td>
    </tr>
  );
}
