import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import Chart from "react-apexcharts";
import { APIs } from "../APIs";

export default function WorkTypeD(props) {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [check, setCheck] = useState(false);
  const [diag, setDiag] = useState({
    options: {
      chart: {
        id: "basic-bar",
      },
      xaxis: {
        categories: [],
      },
      colors: "#2CC17B",
    },
    series: [
      {
        data: [],
      },
    ],
  });

  function getWorksPerfomanceRatio() {
    diag.options.xaxis.categories.length = 0;

    APIs.getWorksPerfomanceRatio(startDate, endDate).then((response) => {
      response.data.map((x) => {
        diag.options.xaxis.categories.push(x.workname);
        diag.series[0].data.push(x.count);
        console.log(diag);
      });
      setDiag(diag);
      setCheck(!check);
      diag.series[0].data.length = 0;
    });
  }
  return (
    <div>
      <p className="texth1" style={{ marginBottom: "0px" }}>
        Соотношение использования вида работ
      </p>
      <p className="texth1" style={{ marginBottom: "0px" }}>
        Выбор диапазона дат:
      </p>
      <div>
        <div className="flex">
          <span style={{ fontSize: "28px", marginRight: "8px" }}>от</span>
          <Form.Group
            style={{
              display: "flex",
              flexDirection: "column",
              margin: "0 0",
            }}
            controlId="formBasicEmail"
          >
            <Form.Control
              style={{ width: "300px" }}
              type="date"
              placeholder="Введите..."
              name="startDate"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                //getWorksPerfomanceRatio(e.target.value, endDate);
              }}
            />
          </Form.Group>
          <span style={{ fontSize: "28px", margin: "8px" }}>до</span>
          <Form.Group
            style={{
              display: "flex",
              flexDirection: "column",
              margin: "0 0",
            }}
            controlId="formBasicEmail"
          >
            <Form.Control
              style={{ width: "300px" }}
              type="date"
              placeholder="Введите..."
              name="endDate"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                //getWorksPerfomanceRatio(startDate, e.target.value);
              }}
            />
          </Form.Group>
          <buttonC
            className="buttonSave"
            style={{ width: "150px", padding: "0px", marginLeft: "12px" }}
            onClick={() => getWorksPerfomanceRatio()}
          >
            {" "}
            Построить
          </buttonC>
        </div>
        {diag.series[0].data.length != 0 ? (
          <center>
            <Chart
              options={diag.options}
              series={diag.series}
              type="bar"
              width="700"
            />
          </center>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
}
