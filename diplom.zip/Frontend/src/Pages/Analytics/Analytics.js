import React, { useEffect, useState } from "react";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";
import "./Analytics.css";
import ScopeWork from "./ScopeWork";
import GetWorkingDays from "./GetWorkingDays";
import Hours from "./Hours";
import WorkTypeD from "./WorkTypeD";
export default function Mapping(props) {
  return (
    <div
      className="card"
      style={{ height: "100%", padding: "0", width: "100%" }}
    >
      <Tabs
        defaultActiveKey="home"
        id="uncontrolled-tab-example"
        className="mb-3"
        style={{ margin: "auto" }}
      >
        <Tab eventKey="home" title="Объем работ">
          <ScopeWork></ScopeWork>
        </Tab>
        <Tab eventKey="profile" title="Дни в которые выполнялись работы">
          <GetWorkingDays></GetWorkingDays>
        </Tab>
        <Tab eventKey="contact" title="Соотношение использования вида работ">
          <WorkTypeD></WorkTypeD>
        </Tab>
        <Tab eventKey="s" title="Количество часов">
          <Hours></Hours>
        </Tab>
      </Tabs>
    </div>
  );
}
