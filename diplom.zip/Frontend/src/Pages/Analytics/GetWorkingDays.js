import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import Chart from "react-apexcharts";
import { APIs } from "../APIs";

export default function GetWorkingDays(props) {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [check, setCheck] = useState(false);
  const [diag, setDiag] = useState({
    options: {
      labels: ["Будни", "Выходные"],
      colors: "#2CC17B",
    },

    series: [],
    chartOptions: {},
  });

  function getWorkingDays() {
    APIs.getWorkingDays(startDate, endDate).then((response) => {
      console.log(startDate, endDate);
      console.log("до", diag.series.length);
      console.log(response.data);

      //diag.splice(0, diag.series.length);
      diag.series.push(response.data.weekends);
      diag.series.push(response.data.workweek);
      setCheck(!check);
      setDiag(diag);
      diag.series.length = 0;
      console.log("после", diag.series.length);
    });
  }

  return (
    <div>
      <p className="texth1" style={{ marginBottom: "0px" }}>
        Дни в которые выполнялись работы
      </p>
      <p className="texth1" style={{ marginBottom: "0px" }}>
        Выбор диапазона дат:
      </p>
      <div>
        <div className="flex">
          <span style={{ fontSize: "28px", marginRight: "8px" }}>от</span>
          <Form.Group
            style={{
              display: "flex",
              flexDirection: "column",
              margin: "0 0",
            }}
            controlId="formBasicEmail"
          >
            <Form.Control
              style={{ width: "300px" }}
              type="date"
              placeholder="Введите..."
              name="startDate"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                //getWorkingDays(e.target.value, endDate);
              }}
            />
          </Form.Group>
          <span style={{ fontSize: "28px", margin: "8px" }}>до</span>
          <Form.Group
            style={{
              display: "flex",
              flexDirection: "column",
              margin: "0 0",
            }}
            controlId="formBasicEmail"
          >
            <Form.Control
              style={{ width: "300px" }}
              type="date"
              placeholder="Введите..."
              name="endDate"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                //getWorkingDays(startDate, e.target.value);
              }}
            />
          </Form.Group>
          <buttonC
            className="buttonSave"
            style={{ width: "150px", padding: "0px", marginLeft: "12px" }}
            onClick={() => getWorkingDays()}
          >
            {" "}
            Построить
          </buttonC>
        </div>
        {diag.series.length != 0 ? (
          <center>
            <Chart
              options={diag.options}
              series={diag.series}
              labels={diag.labels}
              type="donut"
              width="500"
            />
          </center>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
}
