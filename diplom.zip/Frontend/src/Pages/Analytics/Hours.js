import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import Chart from "react-apexcharts";
import { APIs } from "../APIs";
import { Select } from "antd";
export default function Hours(props) {
  const [year, setYear] = useState("");
  const [diag, setDiag] = useState([]);
  const [check, setCheck] = useState(false);
  const years = [
    { id: 1, value: 2018 },
    { id: 2, value: 2019 },
    { id: 3, value: 2020 },
    { id: 4, value: 2021 },
    { id: 5, value: 2022 },
    { id: 6, value: 2023 },
  ];
  function getCountAllWorksHours(year) {
    APIs.getCountAllWorksHours(year).then((response) => {
      response.data.map((x) => {
        diag.push({
          options: {
            chart: {
              id: "basic-bar",
            },
            xaxis: {
              categories: [
                "Январь",
                "Февраль",
                "Март",
                "Апрель",
                "Май",
                "Июнь",
                "Июль",
                "Август",
                "Сентябрь",
                "Октябрь",
                "Ноябрь",
                "Декабрь",
              ],
            },
            colors: "#2CC17B",
          },
          series: [
            {
              name: x.work.workname,
              data: x.months,
            },
          ],
        });
      });
      setCheck(!check);
      setDiag(diag);
      diag.length = 0;
      console.log(diag);
    });
  }
  function handleChange(value) {
    console.log(`selected ${value}`);
  }
  return (
    <div>
      <div className="texth1" style={{ margin: "0", marginRight: "4px" }}>
        Количество часов
      </div>
      <div>
        <div className="flex">
          <span className="texth1" style={{ marginRight: "4px" }}>
            Выберите год:
          </span>
          <Form.Group
            style={{
              display: "flex",
              flexDirection: "column",
            }}
            controlId="formBasicEmail"
            style={{ margin: "0 0" }}
          >
            <Select
              defaultValue="lucy"
              style={{ width: 400 }}
              onChange={handleChange}
              name="year"
              value={year}
              onChange={(e) => {
                setYear(e);
                getCountAllWorksHours(e);
              }}
            >
              {years.map((map) => {
                return (
                  <option key={map.id} value={map.value}>
                    {map.value}
                  </option>
                );
              })}
            </Select>
          </Form.Group>
        </div>
        {diag.length != 0 ? (
          <center>
            {diag.map((x) => {
              return (
                <>
                  <p>{x.series[0].name}</p>
                  <Chart
                    options={x.options}
                    series={x.series}
                    type="bar"
                    width="700"
                  />
                </>
              );
            })}
          </center>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
}
