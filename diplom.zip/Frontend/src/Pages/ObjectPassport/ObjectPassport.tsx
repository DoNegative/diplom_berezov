import React from 'react';
import MainHeader from "../../shared/MainHeader/MainHeader";
import {useAppSelector} from "../../app/hooks/hooks";

const ObjectPassport = () => {

    const {isLoading, error, currentField} = useAppSelector(state => state.fields)

    return (
        <>
            <MainHeader title={'Паспорт объекта'}/>
            <div className="row">
                <div className="col pl-3">
                    {isLoading || (!currentField && !error) ?
                        'Loading...'
                        :
                        <ul className="list-group mb-3">
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Наименование</strong>
                                </div>
                                <span className="text-muted">{currentField ? currentField.name : ''}</span>
                            </li>
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Площадь</strong>
                                </div>
                                <span
                                    className="text-muted">{currentField ? currentField.square.toFixed(2) : ''} м2</span>
                            </li>
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Ширина</strong>
                                </div>
                                <span
                                    className="text-muted">{currentField ? currentField.width.toFixed(2) : ''} м</span>
                            </li>
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Длина</strong>
                                </div>

                                <span
                                    className="text-muted">{currentField ? currentField.length.toFixed(2) : ''} м</span>
                            </li>
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Кол-во завершенных тренировок</strong>
                                </div>

                                <span className="text-muted">0</span>
                            </li>
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Кол-во запланированных тренировок</strong>
                                </div>

                                <span className="text-muted">1</span>
                            </li>
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Кол-во выполненных работ</strong>
                                </div>

                                <span className="text-muted">0</span>
                            </li>
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Кол-во запланированных работ</strong>
                                </div>

                                <span className="text-muted">1</span>
                            </li>
                            <li className="list-group-item d-flex justify-content-between lh-condensed">
                                <div>
                                    <strong className="my-0">Ответственный</strong>
                                </div>

                                <span className="text-muted pr-2" style={{maxHeight: "250px", overflowY: "auto"}}>
                    <ul>
                        {currentField && currentField.responsibles.map(elem =>
                            <li key={elem.id}>
                                <button className="btn btn-sm mt-1">
                                    {elem.name}
                                </button>
                            </li>
                        )}
                    </ul>
                </span>
                            </li>
                        </ul>
                    }
                </div>
                <div className="col">
                    <div className="card shadow mb-4">
                        sssss
                    </div>
                </div>
            </div>
        </>
    );
};

export default ObjectPassport;