import React, { useState, useEffect, Component } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";
import EditClients from "./EditStaff";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
export default function TdStaff(props) {
  useEffect(() => {}, []);
  const [modalWindowEdit, setModalWindowEdit] = useState(false);
  function deleteStaff(id) {
    APIs.deleteStaff(id).then((response) => {
      props.getStaffs();
    });
  }
  return (
    <tr>
      <td>{props.tr.employee.fio}</td>
      <td>{props.tr.employee.phone_number}</td>
      <td>{props.tr.func_name}</td>
      <td>{props.tr.employee.email}</td>
      <td style={{ textAlign: "center", width: "10%" }}>
        <EditOutlined
          style={{ marginRight: "8px" }}
          onClick={() => setModalWindowEdit(true)}
        />{" "}
        <DeleteOutlined onClick={() => deleteStaff(props.tr.employee.id)} />
        <ModalWindow active={modalWindowEdit} setActive={setModalWindowEdit}>
          <EditClients
            id={props.tr.employee.id}
            update={props.getStaffs}
            setActive={setModalWindowEdit}
          ></EditClients>
        </ModalWindow>
      </td>
    </tr>
  );
}
