import React, { useState, useEffect } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import {
  SortAscendingOutlined,
  SortDescendingOutlined,
} from "@ant-design/icons";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import AddStaff from "./AddStaff";
import buttonС from "../components/buttons/buttonС";
import Sort from "../components/sort/Sort";
import TdStaff from "./TdStaff";
import { APIs } from "../APIs";
const StaffPage = () => {
  const [staffArr, setStaffArr] = useState([]);
  const [toggle, setToggle] = useState(false);
  const [modalWindow, setModalWindow] = useState(false);
  const [find, setFind] = useState("");
  const [modalWindowEdit, setModalWindowEdit] = useState(false);
  //Сортировка по имени
  function SortName(check) {
    if (check == 1) {
      setStaffArr(
        staffArr.sort((a, b) => {
          if (a.employee.fio < b.employee.fio) {
            return -1;
          }
          if (a.employee.fio > b.employee.fio) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setStaffArr(
        staffArr.sort((b, a) => {
          if (a.employee.fio < b.employee.fio) {
            return -1;
          }
          if (a.employee.fio > b.employee.fio) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }

  //Сортировка по номеру
  function SortPhone(check) {
    if (check == 1) {
      setStaffArr(
        staffArr.sort((a, b) => {
          if (a.employee.phone_number < b.employee.phone_number) {
            return -1;
          }
          if (a.employee.phone_number > b.employee.phone_number) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setStaffArr(
        staffArr.sort((b, a) => {
          if (a.employee.phone_number < b.employee.phone_number) {
            return -1;
          }
          if (a.employee.phone_number > b.employee.phone_number) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  //Сортировка по должности
  function SortPost(check) {
    if (check == 1) {
      setStaffArr(
        staffArr.sort((a, b) => {
          if (a.func_name < b.func_name) {
            return -1;
          }
          if (a.func_name > b.func_name) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setStaffArr(
        staffArr.sort((b, a) => {
          if (a.func_name < b.func_name) {
            return -1;
          }
          if (a.func_name > b.func_name) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  //Сортировка по почте
  function SortEmail(check) {
    if (check == 1) {
      setStaffArr(
        staffArr.sort((a, b) => {
          if (a.employee.email < b.employee.email) {
            return -1;
          }
          if (a.email > b.email) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setStaffArr(
        staffArr.sort((b, a) => {
          if (a.employee.email < b.employee.email) {
            return -1;
          }
          if (a.employee.email > b.employee.email) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }

  function getStaffs() {
    APIs.getStaffs().then((response) => {
      setStaffArr(response.data);
    });
  }

  useEffect(() => {
    getStaffs();
  }, []);
  return (
    <div className="card">
      <header
        className="cardHeader"
        style={{
          display: "flex",
          flexWrap: "nowrap",
          justifyContent: "space-between",
        }}
      >
        {" "}
        <buttonC
          className="buttonSave"
          style={{ width: "150px", padding: "0px" }}
          onClick={() => setModalWindow(true)}
        >
          {" "}
          Добавить
        </buttonC>
        <ModalWindow active={modalWindow} setActive={setModalWindow}>
          <AddStaff update={getStaffs} setActive={setModalWindow}></AddStaff>
        </ModalWindow>
        <Form.Group
          style={{
            margin: "10px 0 0 0",
            display: "flex",
            flexDirection: "row",
          }}
          controlId="formBasicEmail"
        >
          <Form.Label
            className="Textlabel MainText"
            style={{ textAlign: "left", marginRight: "8px" }}
          >
            Поиск:
          </Form.Label>
          <Form.Control
            style={{ width: "400px" }}
            type="search"
            placeholder="Введите..."
            name="find"
            value={find}
            onChange={(e) => setFind(e.target.value)}
          />
        </Form.Group>
      </header>

      <table className="table  tableCardProj">
        <thead>
          <tr>
            <th scope="col">
              <Sort name={"ФИО"} SortName={SortName}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Номер телефона"} SortName={SortPhone}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Должность"} SortName={SortPost}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Почта"} SortName={SortEmail}></Sort>{" "}
            </th>
          </tr>
        </thead>
        <tbody>
          {staffArr.map((tr) => {
            if (
              (find.length > 0 &&
                (tr.employee.fio.toUpperCase().includes(find.toUpperCase()) ||
                  tr.employee.phone_number
                    .toUpperCase()
                    .includes(find.toUpperCase()) ||
                  tr.func_name.toUpperCase().includes(find.toUpperCase()) ||
                  tr.employee.email
                    .toUpperCase()
                    .includes(find.toUpperCase()))) ||
              find.length === 0
            )
              return (
                <TdStaff key={tr.id} tr={tr} getStaffs={getStaffs}></TdStaff>
              );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default StaffPage;
