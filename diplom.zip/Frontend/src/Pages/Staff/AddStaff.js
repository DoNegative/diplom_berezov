import React, { useState, useEffect, Component } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";
export default function AddStaff(props) {
  useEffect(() => {}, []);

  const [surname, setSurname] = useState("");
  const [patronymic, setPatronymic] = useState("");
  const [email, setEmail] = useState("");
  const [phone_number, setPhone_number] = useState("");
  const [name, setName] = useState("");
  const [functionsArr, setFunctionsArr] = useState([]);
  const [functions, setFunctions] = useState("");
  const { Option } = Select;

  function addStaff() {
    APIs.postStaff({
      name: name,
      surname: surname,
      patronymic: patronymic,
      email: email,
      phone_number: phone_number,
      function_id: functions,
    }).then((response) => {
      props.update();
      props.setActive(false);
    });
  }
  function getFunctions() {
    APIs.getFunctions().then((response) => {
      setFunctionsArr(response.data);
    });
  }
  useEffect(() => {
    getFunctions();
  }, []);
  return (
    <div>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Имя:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Фамилия:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="surname"
          value={surname}
          onChange={(e) => setSurname(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Отчество:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="patronymic"
          value={patronymic}
          onChange={(e) => setPatronymic(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Номер телефона:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="phone_number"
          value={phone_number}
          onChange={(e) => setPhone_number(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Почта:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Должность:
        </Form.Label>
        <Select
          className="MainText"
          style={{ width: "400px" }}
          placeholder="Please select"
          value={functions}
          name="filterType"
          onChange={(e) => {
            setFunctions(e);
            console.log(e);
          }}
        >
          {functionsArr.map((unit) => {
            return (
              <option key={unit.id} value={unit.id}>
                {unit.name}
              </option>
            );
          })}
        </Select>
      </Form.Group>

      <center style={{ marginTop: "15px" }}>
        <span>
          <buttonC
            className="buttonSave"
            style={{ padding: "4px 8px" }}
            onClick={() => {
              addStaff();
            }}
          >
            Сохранить
          </buttonC>
        </span>
        <span style={{ marginLeft: "10px" }}>
          <buttonC
            className="cancelButton"
            style={{ width: "300px" }}
            onClick={() => {
              props.setActive(false);
            }}
          >
            Отмена
          </buttonC>
        </span>
      </center>
    </div>
  );
}
