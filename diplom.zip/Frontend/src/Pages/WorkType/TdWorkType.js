import React, { useState, useEffect, Component } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";
import EditWorkType from "./EditWorkType";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
export default function TdWorkType(props) {
  useEffect(() => {}, []);
  const [modalWindowEdit, setModalWindowEdit] = useState(false);
  function deleteWorkType(id) {
    APIs.deleteWorkType(id).then((response) => {
      props.getWorkType();
    });
  }
  return (
    <tr>
      <td>{props.tr.work.name}</td>
      <td>{props.tr.work.number_of_people}</td>
      <td>{props.tr.unit_name}</td>
      <td style={{ textAlign: "center", width: "10%" }}>
        <EditOutlined
          style={{ marginRight: "8px" }}
          onClick={() => setModalWindowEdit(true)}
        />{" "}
        <DeleteOutlined onClick={() => deleteWorkType(props.tr.work.id)} />
        <ModalWindow active={modalWindowEdit} setActive={setModalWindowEdit}>
          <EditWorkType
            id={props.tr.work.id}
            update={props.getWorkType}
            setActive={setModalWindowEdit}
          ></EditWorkType>
        </ModalWindow>
      </td>
    </tr>
  );
}
