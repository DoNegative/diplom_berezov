import React, { useState, useEffect } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import {
  SortAscendingOutlined,
  SortDescendingOutlined,
} from "@ant-design/icons";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import buttonС from "../components/buttons/buttonС";
import Sort from "../components/sort/Sort";
import { APIs } from "../APIs";
import TdWorkType from "./TdWorkType";
import AddWorkType from "./AddWorkType";
const WorkTypePage = () => {
  const [toggle, setToggle] = useState(false);
  const [modalWindow, setModalWindow] = useState(false);
  const [modalWindowEdit, setModalWindowEdit] = useState(false);
  const [workTypeArr, setWorkTypeArr] = useState([]);
  const [find, setFind] = useState("");
  //Сортировка по имени
  function SortName(check) {
    if (check == 1) {
      setWorkTypeArr(
        workTypeArr.sort((a, b) => {
          if (a.work.name < b.work.name) {
            return -1;
          }
          if (a.work.name > b.work.name) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setWorkTypeArr(
        workTypeArr.sort((b, a) => {
          if (a.work.name < b.work.name) {
            return -1;
          }
          if (a.work.name > b.work.name) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  //Сортировка по количеству людей
  function SortCount(check) {
    if (check == 1) {
      setWorkTypeArr(
        workTypeArr.sort((a, b) => {
          if (a.work.number_of_people < b.work.number_of_people) {
            return -1;
          }
          if (a.work.number_of_people > b.work.number_of_people) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setWorkTypeArr(
        workTypeArr.sort((b, a) => {
          if (a.work.number_of_people < b.work.number_of_people) {
            return -1;
          }
          if (a.work.number_of_people > b.work.number_of_people) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  function SortUnit(check) {
    if (check == 1) {
      setWorkTypeArr(
        workTypeArr.sort((a, b) => {
          if (a.unit_name < b.unit_name) {
            return -1;
          }
          if (a.unit_name > b.unit_name) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setWorkTypeArr(
        workTypeArr.sort((b, a) => {
          if (a.unit_name < b.unit_name) {
            return -1;
          }
          if (a.unit_name > b.unit_name) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }

  function getWorkType() {
    APIs.getWorkType().then((response) => {
      setWorkTypeArr(response.data);
    });
  }

  useEffect(() => {
    getWorkType();
  }, []);
  return (
    <div className="card">
      <header
        className="cardHeader"
        style={{
          display: "flex",
          flexWrap: "nowrap",
          justifyContent: "space-between",
        }}
      >
        {" "}
        <buttonC
          className="buttonSave"
          style={{ width: "150px", padding: "0px" }}
          onClick={() => setModalWindow(true)}
        >
          {" "}
          Добавить
        </buttonC>
        <ModalWindow active={modalWindow} setActive={setModalWindow}>
          <AddWorkType
            update={getWorkType}
            setActive={setModalWindow}
          ></AddWorkType>
        </ModalWindow>
        <Form.Group
          style={{
            margin: "10px 0 0 0",
            display: "flex",
            flexDirection: "row",
          }}
          controlId="formBasicEmail"
        >
          <Form.Label
            className="Textlabel MainText"
            style={{ textAlign: "left", marginRight: "8px" }}
          >
            Поиск:
          </Form.Label>
          <Form.Control
            style={{ width: "400px" }}
            type="search"
            placeholder="Введите..."
            name="find"
            value={find}
            onChange={(e) => setFind(e.target.value)}
          />
        </Form.Group>
      </header>

      <table className="table  tableCardProj">
        <thead>
          <tr>
            <th scope="col">
              <Sort name={"Наименование"} SortName={SortName}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Количество людей"} SortName={SortCount}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Единица измерения"} SortName={SortUnit}></Sort>{" "}
            </th>
          </tr>
        </thead>
        <tbody>
          {workTypeArr.length != 0 &&
            workTypeArr.map((tr) => {
              if (
                (find.length > 0 &&
                  (tr.work.name.toUpperCase().includes(find.toUpperCase()) ||
                    String(tr.work.number_of_people)
                      .toUpperCase()
                      .includes(find.toUpperCase()) ||
                    tr.unit_name.toUpperCase().includes(find.toUpperCase()))) ||
                find.length === 0
              )
                return (
                  <TdWorkType
                    key={tr.work.id}
                    tr={tr}
                    getWorkType={getWorkType}
                  ></TdWorkType>
                );
            })}
        </tbody>
      </table>
    </div>
  );
};

export default WorkTypePage;
