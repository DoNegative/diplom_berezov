import React, { useState, useEffect, Component } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import { Select } from "antd";
import { APIs } from "../APIs";
import buttonС from "../components/buttons/buttonС";
export default function AddWorkType(props) {
  const [name, setName] = useState("");
  const [count, setCount] = useState(0);
  const [unitArr, setUnitArr] = useState([]);
  const [unit, setUnit] = useState("");
  const { Option } = Select;

  function AddWorkType() {
    APIs.postWorkType({
      name: name,
      number_of_people: count,
      typesid: 1,
      unitid: unit,
      hours: 0,
    }).then((response) => {
      props.update();
      props.setActive(false);
    });
  }
  function getUnits() {
    APIs.getUnits().then((response) => {
      setUnitArr(response.data);
    });
  }
  useEffect(() => {
    getUnits();
  }, []);
  return (
    <div>
      <Form.Group
        style={{
          margin: "20px 0 0 0",
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Название:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          margin: "20px 0 0 0",
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Количество человек:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="number"
          placeholder="Введите..."
          name="count"
          value={count}
          onChange={(e) => setCount(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          margin: "20px 0 0 0",
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Единица измерения:
        </Form.Label>
        <Select
          style={{ width: 400 }}
          name="unit"
          value={unit}
          onChange={(e) => setUnit(e)}
        >
          {unitArr.map((unit) => {
            return (
              <option key={unit.id} value={unit.id}>
                {unit.name}
              </option>
            );
          })}
        </Select>
      </Form.Group>
      <center style={{ marginTop: "15px" }}>
        <span>
          <buttonC
            className="buttonSave"
            style={{ padding: "4px 8px" }}
            onClick={() => {
              AddWorkType();
            }}
          >
            Сохранить
          </buttonC>
        </span>
        <span style={{ marginLeft: "10px" }}>
          <buttonC
            className="cancelButton"
            style={{ width: "300px" }}
            onClick={() => {
              props.setActive(false);
            }}
          >
            Отмена
          </buttonC>
        </span>
      </center>
    </div>
  );
}
