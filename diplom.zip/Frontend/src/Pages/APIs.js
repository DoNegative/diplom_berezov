import axios from "axios";
export const APIs = {
  //////////////////////////////////////////////////////////////////Клиенты
  getClients() {
    return axios.get(`/api/ReferenceBooks/getAllClients`);
  },
  postClient(body) {
    return axios.post(`/api/ReferenceBooks/addClient`, body);
  },
  deleteClient(guid) {
    return axios.delete(`/api/ReferenceBooks/deleteClient/${guid}`);
  },
  putClient(id, body) {
    return axios.put(`/api/ReferenceBooks/updateClient/${id}`, body);
  },
  getClientId(id) {
    return axios.get(`/api/ReferenceBooks/getClientById/${id}`);
  },
  ////////////////////////////////////////////////////////////////// Сотрудники
  getStaffs() {
    return axios.get(`/api/ReferenceBooks/getAllEmployees`);
  },
  postStaff(body) {
    return axios.post(`/api/ReferenceBooks/addEmployee`, body);
  },
  deleteStaff(guid) {
    return axios.delete(`/api/ReferenceBooks/deleteEmployee/${guid}`);
  },
  putStaff(id, body) {
    return axios.put(`/api/ReferenceBooks/updateEmployee/${id}`, body);
  },
  getStaffId(id) {
    return axios.get(`/api/ReferenceBooks/getEmployeeById/${id}`);
  },
  ////////////////////////////////////////////////////////////////// Должности
  getFunctions() {
    return axios.get(`/api/ReferenceBooks/getAllFunctions`);
  },

  ////////////////////////////////////////////////////////////////// Поля
  getFields() {
    return axios.get(`/api/ReferenceBooks/getAllPropertys`);
  },
  deleteFields(guid) {
    return axios.delete(`/api/ReferenceBooks/deleteProperty/${guid}`);
  },
  postField(body) {
    return axios.post(`/api/ReferenceBooks/addProperty`, body);
  },
  putField(id, body) {
    return axios.put(`/api/ReferenceBooks/updateProperty/${id}`, body);
  },
  getFieldId(id) {
    return axios.get(`/api/ReferenceBooks/getPropertyById/${id}`);
  },
  ////////////////////////////////////////////////////////////////// Единицы измерения
  getUnits() {
    return axios.get(`/api/ReferenceBooks/getAllUnits`);
  },
  deleteUnits(guid) {
    return axios.delete(`/api/ReferenceBooks/deleteUnit/${guid}`);
  },
  postUnits(body) {
    return axios.post(`/api/ReferenceBooks/addUnit`, body);
  },
  getUnitId(id) {
    return axios.get(`/api/ReferenceBooks/getUnitById/${id}`);
  },
  putUnit(id, body) {
    return axios.put(`/api/ReferenceBooks/updateUnit/${id}`, body);
  },
  ////////////////////////////////////////////////////////////////// Последняя координата
  getLastLocationById(id) {
    return axios.get(`/api/Tracking/getLastLocationById/${id}`);
  },
  ////////////////////////////////////////////////////////////////// План
  postPlan(body) {
    return axios.post(`/api/Plan/addPlan`, body);
  },
  getPlan(id) {
    return axios.get(`/api/Plan/getPlanByEmployeeId/${id}`);
  },
  getPlanDate(date, id) {
    return axios.get(`/api/Plan/getPlansByDateAndEmployeeId/${date}&&${id}`);
  },
  ////////////////////////////////////////////////////////////////// Факта

  getFact(id) {
    return axios.get(`/api/Fact/getFactByEmployeeId/${id}`);
  },
  getFactDate(date, id) {
    return axios.get(`/api/Fact/getFactsByDateAndEmployeeId/${date}&&${id}`);
  },
  ////////////////////////////////////////////////////////////////// Виды работы

  getWorkType() {
    return axios.get(`/api/ReferenceBooks/getAllWorks`);
  },
  postWorkType(body) {
    return axios.post(`/api/ReferenceBooks/addWork`, body);
  },
  putWorkType(id, body) {
    return axios.put(`/api/ReferenceBooks/updateWork/${id}`, body);
  },
  deleteWorkType(guid) {
    return axios.delete(`/api/ReferenceBooks/deleteWork/${guid}`);
  },
  getWorkTypeID(id) {
    return axios.get(`/api/ReferenceBooks/getWorkById/${id}`);
  },
  ////////////////////////////////////////////////////////////////// Дни в которые выполнялась работа
  getWorkingDays(sd, ed) {
    return axios.get(`/api/Analitic/getWorkingDays/${sd}&&${ed}`);
  },
  ////////////////////////////////////////////////////////////////// Объем работ
  getCountAllWorksScope(year) {
    return axios.get(`/api/Analitic/countAllWorksScope/${year}`);
  },
  ////////////////////////////////////////////////////////////////// Часы
  getCountAllWorksHours(year) {
    return axios.get(`/api/Analitic/countAllWorksHours/${year}`);
  },
  ////////////////////////////////////////////////////////////////// Соотношения вида работ
  getWorksPerfomanceRatio(sd, ed) {
    return axios.get(`/api/Analitic/getWorksPerfomanceRatio/${sd}&&${ed}`);
  },
};
