import React, { useState, useEffect } from "react";

import {
  SortAscendingOutlined,
  SortDescendingOutlined,
} from "@ant-design/icons";

const Sort = (props) => {
  const [toggle, setToggle] = useState(false);

  useEffect(() => {}, []);
  if (toggle == false) {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <span>{props.name}</span>
        <SortAscendingOutlined
          onClick={() => {
            props.SortName(1);
            setToggle(true);
          }}
        />
      </div>
    );
  } else {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <span>{props.name}</span>
        <SortDescendingOutlined
          onClick={() => {
            props.SortName(0);
            setToggle(false);
          }}
        />{" "}
      </div>
    );
  }
};

export default Sort;
