import React, { useState } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import "./button.css";

const buttonС =
  () =>
  ({ children, onClick, className, disabled, active, ...attrs }) => {
    const onClickAction = (e) => {
      if (disabled) {
        e.preventDEfault();
      } else {
        return onClick(e);
      }
    };

    const classes = classNames("btn", className, { active });

    const Tag = attrs.href ? "a" : "button";

    return (
      <button
        {...attrs}
        className={classes}
        disabled={disabled}
        onClick={onClickAction}
      >
        {children}
      </button>
    );
  };

buttonС.propTypes = {
  children: PropTypes.node,
  onClick: PropTypes.func,
  className: PropTypes.string,
  disabled: PropTypes.bool,
  active: PropTypes.bool,
};
buttonС.defaultProps = {
  children: "Default button",
  onClick: () => {},
  className: "",
  disabled: false,
  active: false,
};
export default buttonС;
