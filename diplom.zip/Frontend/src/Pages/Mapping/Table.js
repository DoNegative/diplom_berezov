import React, { useState, useEffect, Component } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { Select } from "antd";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import { APIs } from "../APIs";
import "./Mapping.css";
import Form from "react-bootstrap/Form";
import buttonС from "../components/buttons/buttonС";
import { PlusOutlined, LogoutOutlined } from "@ant-design/icons";
import AddWork from "./AddWork";
export default function Mapping(props) {
  const [modalWindow, setModalWindow] = useState(false);
  const [date, setDate] = useState();

  function getPlanDate(date) {
    APIs.getPlanDate(date, props.id).then((response) => {
      props.setPlanArr(response.data);
      console.log(response.data);
    });
  }
  function getFactDate(date) {
    APIs.getFactDate(date, props.id).then((response) => {
      props.setFactArr(response.data);
      console.log(response.data);
    });
  }

  useEffect(() => {
    console.log(props.factArr);
  }, []);
  return (
    <div className="workCard">
      <div className="workHeader">
        <buttonС
          onClick={() => setModalWindow(true)}
          className="buttonSave circle"
        >
          <PlusOutlined style={{ color: "black" }} />
        </buttonС>
        <ModalWindow active={modalWindow} setActive={setModalWindow}>
          <AddWork
            setActive={setModalWindow}
            update={props.update}
            id={props.id}
          ></AddWork>
        </ModalWindow>
        {props.pF == 0 ? (
          <Form.Control
            id="dateHead1"
            style={{ width: "150px", height: "30px", marginRight: "20px" }}
            type="date"
            placeholder="Введите..."
            name="date"
            value={date}
            onChange={(e) => getPlanDate(e.target.value)}
          />
        ) : (
          <Form.Control
            id="dateHead2"
            style={{ width: "150px", height: "30px", marginRight: "20px" }}
            type="date"
            placeholder="Введите..."
            name="date"
            value={date}
            onChange={(e) => getFactDate(e.target.value)}
          />
        )}
      </div>

      {props.pF == 0 ? (
        <div className="scroll-table">
          <table>
            <thead>
              <tr>
                <th scope="col">Наименование</th>
                <th scope="col">Колличество</th>
                <th scope="col">Адрес</th>
              </tr>
            </thead>
          </table>
          <div className="scroll-table-body">
            <table>
              <tbody>
                {props.planArr.map((pl) => {
                  return (
                    <tr>
                      <td>{pl.plan.workname}</td>
                      <td>{pl.plan.plan.count}</td>
                      <td>{pl.property.adress}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="scroll-table">
          <table>
            <thead>
              <tr>
                <th scope="col">Наименование</th>
                <th scope="col">Колличество</th>
                <th scope="col">Адрес</th>
                <th scope="col"></th>
              </tr>
            </thead>
          </table>
          <div className="scroll-table-body">
            <table>
              <tbody>
                {props.factArr.map((pl) => {
                  console.log(pl);

                  return (
                    <tr onClick={() => props.setPolyline(true)}>
                      <td>{pl.fact.workname}</td>
                      <td>{pl.fact.fact.count}</td>
                      <td>{pl.property.adress}</td>
                      <td
                        style={{
                          display: "flex",
                          justifyContent: "center",
                          alignItem: "center",
                        }}
                      >
                        <LogoutOutlined
                          onClick={() => {
                            {
                              pl.routes.polyroutes.map((map) => {
                                if (map.employeeId == props.id) {
                                  return props.setPolylinesArr(map.polyline);
                                }
                                console.log(map.polyline);
                              });
                              pl.routes.polyroutes.map((map) => {
                                if (map.employeeId == props.id) {
                                  return props.setCenter(map.polyline[0]);
                                }
                                console.log("центр", props.center);
                              });
                              props.setPolyline(true);
                            }
                          }}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
