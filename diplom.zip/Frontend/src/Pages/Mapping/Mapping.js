import React, { useState, useEffect, Component } from "react";
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  Polyline,
  useMap,
} from "react-leaflet";
import L from "leaflet";
import { Select } from "antd";
import { APIs } from "../APIs";
import "./Mapping.css";
import Table from "./Table";

export default function Mapping(props) {
  const { Option } = Select;
  const [staffArr, setStaffArr] = useState([]);
  const [check, setCheck] = useState(false);
  const [toggle, setToggle] = useState(false);
  const [track, setTrack] = useState({});
  const [pF, setPF] = useState(0);
  const [id, setId] = useState("");
  const [planArr, setPlanArr] = useState([]);
  const [factArr, setFactArr] = useState([]);
  const [center, setCenter] = useState([]);
  const [polylinesArr, setPolylinesArr] = useState([]);
  const [polyline, setPolyline] = useState(false);
  const [marker, setMarker] = useState(false);
  const blackOptions = { color: "red" };
  var greenIcon = new L.Icon({
    iconUrl:
      "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41],
  });

  function getStaffs() {
    APIs.getStaffs().then((response) => {
      setStaffArr(response.data);
      console.log(response.data);
    });
  }
  function handleChange(value) {
    console.log(`selected ${value}`);

    getLastLocationById(value);
    setId(value);
    getPlan(value);
    getFact(value);
    setPolyline(false);
  }
  function SetPlF(e) {
    setPF(e);
    setPolyline(false);
    if (e == 0) {
      setPolyline(false);
      setMarker(true);
    } else {
      setMarker(false);
    }
  }
  function getLastLocationById(id) {
    const arr = [];
    APIs.getLastLocationById(id).then((response) => {
      setTrack(response.data);
      arr[0] = response.data.lat;
      arr[1] = response.data.lng;
      setCenter(arr);
      setCheck(true);
      setToggle(!toggle);
      console.log("центр", center);
      if (pF == 0) setMarker(true);
      console.log(response.data);
    });
  }
  function getPlan(id) {
    APIs.getPlan(id).then((response) => {
      setPlanArr(response.data);
      console.log(response.data);
    });
  }
  function getFact(id) {
    APIs.getFact(id).then((response) => {
      setFactArr(response.data);
      console.log(response.data);
    });
  }
  function SetViewOnClick({ coords }) {
    const map = useMap();
    map.setView(coords, map.getZoom());

    return null;
  }
  useEffect(() => {
    getStaffs();
  }, []);
  return (
    <div>
      <div className="polosa">
        <div style={{ marginRight: "8px" }}>Карта сотрудников:</div>

        <Select
          allowClear
          style={{ width: "20%" }}
          placeholder="Выберите сотрудника"
          onChange={handleChange}
        >
          {staffArr.map((st) => {
            return (
              <option key={st.employee.id} value={st.employee.id}>
                {" "}
                {st.employee.fio}{" "}
              </option>
            );
          })}
        </Select>
        <Select
          allowClear
          style={{ width: "20%", marginLeft: "auto", marginRight: "20px" }}
          placeholder="Please select"
          onChange={(e) => SetPlF(e)}
          defaultValue={0}
        >
          <option value={0}>План</option>
          <option value={1}>Факт</option>
        </Select>
      </div>
      {check == false ? (
        <div className="polosa" style={{ padding: "0px", height: "500px" }}>
          <MapContainer
            center={[48.72688415083403, 44.54241087311681]}
            zoom={13}
          >
            <TileLayer url="http://{s}.tile.osm.org/{z}/{x}/{y}.png" />
          </MapContainer>
        </div>
      ) : (
        <div className="polosa polosaID">
          <div style={{ height: "480px", width: "55%" }}>
            <MapContainer center={center} zoom={13}>
              <TileLayer url="http://{s}.tile.osm.org/{z}/{x}/{y}.png" />
              {track.length != 0 && marker == true && (
                <Marker
                  icon={greenIcon}
                  position={[track.lat, track.lng]}
                ></Marker>
              )}
              {polyline == true && (
                <Polyline pathOptions={blackOptions} positions={polylinesArr} />
              )}
              <SetViewOnClick coords={center} />
            </MapContainer>
          </div>
          <div>
            <Table
              planArr={planArr}
              factArr={factArr}
              setPlanArr={setPlanArr}
              setFactArr={setFactArr}
              id={id}
              pF={pF}
              update={getPlan}
              setPolylinesArr={setPolylinesArr}
              setPolyline={setPolyline}
              setCenter={setCenter}
              center={center}
            ></Table>
          </div>
        </div>
      )}
    </div>
  );
}
