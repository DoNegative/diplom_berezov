import React, { useState, useEffect, Component } from "react";

import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";

export default function AddSWork(props) {
  const [workArr, setWorkArr] = useState([]);
  const [work, setWork] = useState("");
  const [propertyArr, setPropertyArr] = useState([]);
  const [property, setProperty] = useState("");
  const [date, setDate] = useState("");
  const [count, setCount] = useState(0);
  const [countPeople, setCountPeople] = useState(0);
  const [hours, setHours] = useState("");
  const [peopleArr, setPeopleArr] = useState([]);
  const [Arr, setArr] = useState([]);

  function getFields() {
    APIs.getFields().then((response) => {
      setPropertyArr(response.data);
    });
  }
  function getStaffs() {
    APIs.getStaffs().then((response) => {
      setPeopleArr(response.data);
      console.log(response.data);
    });
  }

  function getWorkType() {
    APIs.getWorkType().then((response) => {
      setWorkArr(response.data);
    });
  }
  const { Option } = Select;

  function postPlan() {
    APIs.postPlan({
      plan: {
        workid: work,
        propertyid: property,
        date: date,
        count: count,
        number_of_people: countPeople,
        hours: hours,
      },
      empids: Arr,
    }).then((response) => {
      props.update(props.id);
      props.setActive(false);
    });
  }

  useEffect(() => {
    getFields();
    getWorkType();
    getStaffs();
  }, []);
  return (
    <div>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Тип работ:
        </Form.Label>
        <Select
          className="MainText"
          style={{ width: "400px" }}
          placeholder="Please select"
          value={work}
          name="work"
          onChange={(e) => {
            setWork(e);
            console.log(e);
          }}
        >
          {workArr.map((work) => {
            return (
              <option key={work.work.id} value={work.work.id}>
                {work.work.name}
              </option>
            );
          })}
        </Select>
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Участок:
        </Form.Label>
        <Select
          className="MainText"
          style={{ width: "400px" }}
          placeholder="Please select"
          value={property}
          name="property"
          onChange={(e) => {
            setProperty(e);
          }}
        >
          {propertyArr.map((property) => {
            return (
              <option key={property.property.id} value={property.property.id}>
                {property.property.adress}
              </option>
            );
          })}
        </Select>
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Количество людей:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="countPeople"
          value={countPeople}
          onChange={(e) => setCountPeople(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Количество:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="count"
          value={count}
          onChange={(e) => setCount(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Время на работу, в часах:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="text"
          placeholder="Введите..."
          name="hours"
          value={hours}
          onChange={(e) => setHours(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Дата начала:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="date"
          placeholder="Введите..."
          name="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Исполнители:
        </Form.Label>
        <Select
          mode="multiple"
          allowClear
          style={{ width: "100%" }}
          placeholder="Выберите..."
          value={Arr}
          onChange={(e) => {
            setArr(e);
            console.log(e);
          }}
        >
          {peopleArr.map((st) => {
            console.log(st);
            return (
              <option key={st.employee.id} value={st.employee.id}>
                {" "}
                {st.employee.name}{" "}
              </option>
            );
          })}
        </Select>
      </Form.Group>
      <center style={{ marginTop: "15px" }}>
        <span>
          <buttonC
            className="buttonSave"
            style={{ padding: "4px 8px" }}
            onClick={() => {
              postPlan();
            }}
          >
            Сохранить
          </buttonC>
        </span>
        <span style={{ marginLeft: "10px" }}>
          <buttonC
            className="cancelButton"
            style={{ width: "300px" }}
            onClick={() => {
              props.setActive(false);
            }}
          >
            Отмена
          </buttonC>
        </span>
      </center>
    </div>
  );
}
