import React, { useState, useEffect, Component } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";
import EditFields from "./EditFields";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
export default function TdFields(props) {
  useEffect(() => {}, []);
  const [modalWindowEdit, setModalWindowEdit] = useState(false);
  function deleteFields(id) {
    APIs.deleteFields(id).then((response) => {
      props.getFields();
    });
  }
  return (
    <tr>
      <td>{props.tr.property.adress}</td>
      <td>{props.tr.property.width}</td>
      <td>{props.tr.property.length}</td>
      <td>{props.tr.property.area_size}</td>
      <td>{props.tr.client.fio}</td>
      <td style={{ textAlign: "center", width: "10%" }}>
        <EditOutlined
          style={{ marginRight: "8px" }}
          onClick={() => setModalWindowEdit(true)}
        />{" "}
        <DeleteOutlined onClick={() => deleteFields(props.tr.property.id)} />
        <ModalWindow active={modalWindowEdit} setActive={setModalWindowEdit}>
          <EditFields
            id={props.tr.property.id}
            update={props.getFields}
            setActive={setModalWindowEdit}
          ></EditFields>
        </ModalWindow>
      </td>
    </tr>
  );
}
