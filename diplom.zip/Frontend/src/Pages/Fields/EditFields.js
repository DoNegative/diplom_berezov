import React, { useState, useEffect, Component } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";
export default function EditFields(props) {
  const [adress, setAdress] = useState("");
  const [area_size, setArea_size] = useState("");
  const [length, setLength] = useState("");
  const [width, setWidth] = useState("");
  const [client_id, setClient_id] = useState("");
  const [clientsArr, setClientsArr] = useState([]);
  const { Option } = Select;
  function getClients() {
    APIs.getClients().then((response) => {
      setClientsArr(response.data);
    });
  }
  function EditField(id) {
    APIs.putField(id, {
      adress: adress,
      area_size: area_size,
      length: length,
      width: width,
      client_id: client_id,
    }).then((response) => {
      props.update();
      props.setActive(false);
    });
  }
  function getFieldId() {
    console.log(123);
    APIs.getFieldId(props.id).then((response) => {
      console.log(response.data);
      setAdress(response.data.property.adress);
      setWidth(response.data.property.width);
      setLength(response.data.property.length);
      setArea_size(response.data.property.area_size);
      setClient_id(response.data.client.id);
    });
  }
  useEffect(() => {
    getFieldId();
    getClients();
  }, []);
  return (
    <div>
      <Form.Group
        style={{
          margin: "20px 0 0 0",
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Адрес:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="adress"
          value={adress}
          onChange={(e) => setAdress(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          margin: "20px 0 0 0",
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Длина:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="length"
          value={length}
          onChange={(e) => setLength(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          margin: "20px 0 0 0",
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Ширина:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="width"
          value={width}
          onChange={(e) => setWidth(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          margin: "20px 0 0 0",
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Площадь:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="area_size"
          value={area_size}
          onChange={(e) => setArea_size(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          margin: "20px 0 0 0",
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Владелец:
        </Form.Label>
        <Select
          defaultValue="lucy"
          style={{ width: 400 }}
          name="client_id"
          value={client_id}
          onChange={(e) => setClient_id(e)}
        >
          {clientsArr.map((unit) => {
            return (
              <option key={unit.id} value={unit.id}>
                {unit.name}
              </option>
            );
          })}
        </Select>
      </Form.Group>
      <center style={{ marginTop: "15px" }}>
        <span>
          <buttonC
            className="buttonSave"
            style={{ padding: "4px 8px" }}
            onClick={() => {
              EditField(props.id);
            }}
          >
            Сохранить
          </buttonC>
        </span>
        <span style={{ marginLeft: "10px" }}>
          <buttonC
            className="cancelButton"
            style={{ width: "300px" }}
            onClick={() => {
              props.setActive(false);
            }}
          >
            Отмена
          </buttonC>
        </span>
      </center>
    </div>
  );
}
