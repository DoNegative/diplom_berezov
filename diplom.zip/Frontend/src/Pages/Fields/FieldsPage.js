import React, { useState, useEffect } from "react";
import "./Fpage.css";
import Form from "react-bootstrap/Form";
import {
  SortAscendingOutlined,
  SortDescendingOutlined,
} from "@ant-design/icons";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import AddFields from "./AddFields";

import buttonС from "../components/buttons/buttonС";
import Sort from "../components/sort/Sort";
import TdFields from "./TdFields";
import { APIs } from "../APIs";
const FieldsPage = () => {
  const [toggle, setToggle] = useState(false);
  const [modalWindow, setModalWindow] = useState(false);
  const [modalWindowEdit, setModalWindowEdit] = useState(false);
  const [fieldsArr, setFieldsArr] = useState([]);
  const [find, setFind] = useState("");
  //Сортировка по имени
  function SortName(check) {
    if (check == 1) {
      setFieldsArr(
        fieldsArr.sort((a, b) => {
          if (a.property.adress < b.property.adress) {
            return -1;
          }
          if (a.property.adress > b.property.adress) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setFieldsArr(
        fieldsArr.sort((b, a) => {
          if (a.property.adress < b.property.adress) {
            return -1;
          }
          if (a.property.adress > b.property.adress) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  //Сортировка по ширине
  function SortLength(check) {
    if (check == 1) {
      setFieldsArr(
        fieldsArr.sort((a, b) => {
          if (a.property.width < b.property.width) {
            return -1;
          }
          if (a.property.width > b.property.width) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setFieldsArr(
        fieldsArr.sort((b, a) => {
          if (a.property.width < b.property.width) {
            return -1;
          }
          if (a.property.width > b.property.width) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  //Сортировка по длине
  function SortHeight(check) {
    if (check == 1) {
      setFieldsArr(
        fieldsArr.sort((a, b) => {
          if (a.property.length < b.property.length) {
            return -1;
          }
          if (a.property.length > b.property.length) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setFieldsArr(
        fieldsArr.sort((b, a) => {
          if (a.property.length < b.property.length) {
            return -1;
          }
          if (a.property.length > b.property.length) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  //Сортировка по владельцу
  function SortOwner(check) {
    if (check == 1) {
      setFieldsArr(
        fieldsArr.sort((a, b) => {
          if (a.client.fio < b.client.fio) {
            return -1;
          }
          if (a.client.fio > b.client.fio) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setFieldsArr(
        fieldsArr.sort((b, a) => {
          if (a.client.fio < b.client.fio) {
            return -1;
          }
          if (a.client.fio > b.client.fio) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  //Сортировка по площади
  function SortSquare(check) {
    if (check == 1) {
      setFieldsArr(
        fieldsArr.sort((a, b) => {
          if (a.property.area_size < b.property.area_size) {
            return -1;
          }
          if (a.property.area_size > b.property.area_size) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setFieldsArr(
        fieldsArr.sort((b, a) => {
          if (a.property.area_size < b.property.area_size) {
            return -1;
          }
          if (a.property.area_size > b.property.area_size) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  function getFields() {
    APIs.getFields().then((response) => {
      setFieldsArr(response.data);
    });
  }

  useEffect(() => {
    getFields();
  }, []);
  return (
    <div className="card">
      <header
        className="cardHeader"
        style={{
          display: "flex",
          flexWrap: "nowrap",
          justifyContent: "space-between",
        }}
      >
        {" "}
        <buttonC
          className="buttonSave"
          style={{ width: "150px", padding: "0px" }}
          onClick={() => setModalWindow(true)}
        >
          {" "}
          Добавить
        </buttonC>
        <ModalWindow active={modalWindow} setActive={setModalWindow}>
          <AddFields update={getFields} setActive={setModalWindow}></AddFields>
        </ModalWindow>
        <Form.Group
          style={{
            margin: "10px 0 0 0",
            display: "flex",
            flexDirection: "row",
          }}
          controlId="formBasicEmail"
        >
          <Form.Label
            className="Textlabel MainText"
            style={{ textAlign: "left", marginRight: "8px" }}
          >
            Поиск:
          </Form.Label>
          <Form.Control
            style={{ width: "400px" }}
            type="search"
            placeholder="Введите..."
            name="find"
            value={find}
            onChange={(e) => setFind(e.target.value)}
          />
        </Form.Group>
      </header>

      <table className="table  tableCardProj">
        <thead>
          <tr>
            <th scope="col">
              <Sort name={"Адресс"} SortName={SortName}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Ширина"} SortName={SortLength}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Длина"} SortName={SortLength}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Площадь"} SortName={SortSquare}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Владелец"} SortName={SortOwner}></Sort>{" "}
            </th>
          </tr>
        </thead>
        <tbody>
          {fieldsArr.length != 0 &&
            fieldsArr.map((tr) => {
              if (
                (find.length > 0 &&
                  (tr.property.adress
                    .toUpperCase()
                    .includes(find.toUpperCase()) ||
                    String(tr.property.area_size)
                      .toUpperCase()
                      .includes(find.toUpperCase()) ||
                    String(tr.property.width)
                      .toUpperCase()
                      .includes(find.toUpperCase()) ||
                    String(tr.property.length)
                      .toUpperCase()
                      .includes(find.toUpperCase()) ||
                    tr.client.fio
                      .toUpperCase()
                      .includes(find.toUpperCase()))) ||
                find.length === 0
              )
                return (
                  <TdFields
                    key={tr.id}
                    tr={tr}
                    getFields={getFields}
                  ></TdFields>
                );
            })}
        </tbody>
      </table>
    </div>
  );
};

export default FieldsPage;
