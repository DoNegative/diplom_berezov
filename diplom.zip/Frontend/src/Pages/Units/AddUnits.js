import React, { useState, useEffect, Component } from "react";

import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";
export default function AddUnits(props) {
  useEffect(() => {}, []);

  const [abbreviation, setAbbreviation] = useState("");
  const [name, setName] = useState("");
  const { Option } = Select;

  function addUnits() {
    APIs.postUnits({
      name: name,
      abbreviation: abbreviation,
    }).then((response) => {
      props.update();
      props.setActive(false);
    });
  }

  return (
    <div>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Имя:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </Form.Group>
      <Form.Group
        style={{
          display: "flex",
          flexDirection: "column",
        }}
        controlId="formBasicEmail"
      >
        <Form.Label
          className="Textlabel MainText"
          style={{ textAlign: "left", marginRight: "8px" }}
        >
          Аббревиатура:
        </Form.Label>
        <Form.Control
          style={{ width: "400px" }}
          type="search"
          placeholder="Введите..."
          name="abbreviation"
          value={abbreviation}
          onChange={(e) => setAbbreviation(e.target.value)}
        />
      </Form.Group>

      <center style={{ marginTop: "15px" }}>
        <span>
          <buttonC
            className="buttonSave"
            style={{ padding: "4px 8px" }}
            onClick={() => {
              addUnits();
            }}
          >
            Сохранить
          </buttonC>
        </span>
        <span style={{ marginLeft: "10px" }}>
          <buttonC
            className="cancelButton"
            style={{ width: "300px" }}
            onClick={() => {
              props.setActive(false);
            }}
          >
            Отмена
          </buttonC>
        </span>
      </center>
    </div>
  );
}
