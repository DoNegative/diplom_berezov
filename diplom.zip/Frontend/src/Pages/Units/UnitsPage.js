import React, { useState, useEffect } from "react";
import Form from "react-bootstrap/Form";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import AddUnits from "./AddUnits";
import buttonС from "../components/buttons/buttonС";
import Sort from "../components/sort/Sort";
import TdUnits from "./TdUnits";
import { APIs } from "../APIs";
const UnitsPage = () => {
  const [toggle, setToggle] = useState(false);
  const [modalWindow, setModalWindow] = useState(false);
  const [unitsArr, setUnitsArr] = useState([]);
  const [find, setFind] = useState("");
  //Сортировка по имени
  function SortName(check) {
    if (check == 1) {
      setUnitsArr(
        unitsArr.sort((a, b) => {
          if (a.name < b.name) {
            return -1;
          }
          if (a.name > b.name) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setUnitsArr(
        unitsArr.sort((b, a) => {
          if (a.name < b.name) {
            return -1;
          }
          if (a.name > b.name) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }
  //Сортировка по ширине
  function SortAB(check) {
    if (check == 1) {
      setUnitsArr(
        unitsArr.sort((a, b) => {
          if (a.abbreviation < b.abbreviation) {
            return -1;
          }
          if (a.abbreviation > b.abbreviation) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    } else {
      setUnitsArr(
        unitsArr.sort((b, a) => {
          if (a.abbreviation < b.abbreviation) {
            return -1;
          }
          if (a.abbreviation > b.abbreviation) {
            return 1;
          }
          return 0;
        })
      );
      setToggle(!toggle);
    }
  }

  function getUnits() {
    APIs.getUnits().then((response) => {
      setUnitsArr(response.data);
    });
  }

  useEffect(() => {
    getUnits();
  }, []);
  return (
    <div className="card">
      <header
        className="cardHeader"
        style={{
          display: "flex",
          flexWrap: "nowrap",
          justifyContent: "space-between",
        }}
      >
        {" "}
        <buttonC
          className="buttonSave"
          style={{ width: "150px", padding: "0px" }}
          onClick={() => setModalWindow(true)}
        >
          {" "}
          Добавить
        </buttonC>
        <ModalWindow active={modalWindow} setActive={setModalWindow}>
          <AddUnits update={getUnits} setActive={setModalWindow}></AddUnits>
        </ModalWindow>
        <Form.Group
          style={{
            margin: "10px 0 0 0",
            display: "flex",
            flexDirection: "row",
          }}
          controlId="formBasicEmail"
        >
          <Form.Label
            className="Textlabel MainText"
            style={{ textAlign: "left", marginRight: "8px" }}
          >
            Поиск:
          </Form.Label>
          <Form.Control
            style={{ width: "400px" }}
            type="search"
            placeholder="Введите..."
            name="find"
            value={find}
            onChange={(e) => setFind(e.target.value)}
          />
        </Form.Group>
      </header>

      <table className="table  tableCardProj">
        <thead>
          <tr>
            <th scope="col">
              <Sort name={"Наименование"} SortName={SortName}></Sort>{" "}
            </th>
            <th scope="col">
              <Sort name={"Аббревиатура"} SortName={SortAB}></Sort>{" "}
            </th>
          </tr>
        </thead>
        <tbody>
          {unitsArr.map((tr) => {
            if (
              (find.length > 0 &&
                (tr.abbreviation.toUpperCase().includes(find.toUpperCase()) ||
                  tr.name.toUpperCase().includes(find.toUpperCase()))) ||
              find.length === 0
            )
              return (
                <TdUnits key={tr.id} tr={tr} getUnits={getUnits}></TdUnits>
              );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default UnitsPage;
