import React, { useState, useEffect, Component } from "react";

import Form from "react-bootstrap/Form";
import { Select } from "antd";
import buttonС from "../components/buttons/buttonС";
import { APIs } from "../APIs";
import EditUnit from "./EditUnit";
import ModalWindow from "../components/ModalWindow/ModalWindow";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
export default function TdUnits(props) {
  useEffect(() => {
    console.log(props);
  }, []);
  const [modalWindowEdit, setModalWindowEdit] = useState(false);
  function deleteUnits(id) {
    APIs.deleteUnits(id).then((response) => {
      props.getUnits();
    });
  }
  return (
    <tr>
      <td>{props.tr.name}</td>
      <td>{props.tr.abbreviation}</td>

      <td style={{ textAlign: "center", width: "10%" }}>
        <EditOutlined
          style={{ marginRight: "8px" }}
          onClick={() => setModalWindowEdit(true)}
        />{" "}
        <DeleteOutlined onClick={() => deleteUnits(props.tr.id)} />
        <ModalWindow active={modalWindowEdit} setActive={setModalWindowEdit}>
          <EditUnit
            id={props.tr.id}
            update={props.getUnits}
            setActive={setModalWindowEdit}
          ></EditUnit>
        </ModalWindow>
      </td>
    </tr>
  );
}
