export interface ICompany {
    idCompany: number | null
    companyName: string | null
    idRate: number | null
}