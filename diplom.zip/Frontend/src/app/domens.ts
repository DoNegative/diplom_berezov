export const authDomen = 'http://gazonauth.somee.com/api'
export const mainDomen = 'http://gazon.somee.com/api'