import React from 'react';
import {BrowserRouter as Router, Switch, Redirect, Route} from 'react-router-dom'
import './App.scss';
import 'antd/dist/antd.css';
import 'leaflet/dist/leaflet.css';
import PlanPage from "./Pages/Plan/PlanPage";
import FieldsPage from "./Pages/Fields/FieldsPage";
import MainLayout from "./Layouts/MainLayout/MainLayout";
import FactPage from "./Pages/Fact/FactPage";
import UnitsPage from "./Pages/Units/UnitsPage";
import ObjectPassport from "./Pages/ObjectPassport/ObjectPassport";
import SettingsPage from "./Pages/Settings/SettingsPage";
import ClientsPage from "./Pages/Clients/ClientsPage";
import StaffPage from "./Pages/Staff/StaffPage";
import Mapping from "./Pages/Mapping/Mapping";
import WorkTypePage from "./Pages/WorkType/WorkTypePage";
import Analytics from "./Pages/Analytics/Analytics"



const App: React.FC = () => {
    return (
        <div className="App">
            <Router>
                <Switch>
                    <Route path={'/'} exact>
                        <MainLayout link={'/'}>
                            <StaffPage />
                        </MainLayout>
                    </Route>
                    <Route path={'/fields/passport'} exact>
                        <MainLayout link={'/fields/passport'}>
                            <ObjectPassport />
                        </MainLayout>
                    </Route>
                    <Route path={'/fact-works'} exact>
                        <MainLayout link={'/fact-works'}>
                            <FactPage />
                        </MainLayout>
                    </Route>
                    <Route path={'/fields'} exact>
                        <MainLayout link={'/fields'}>
                            <FieldsPage />
                        </MainLayout>
                    </Route>
                    <Route path={'/clients'} exact>
                        <MainLayout link={'/clients'}>
                            <ClientsPage />
                        </MainLayout>
                    </Route>
                    <Route path={'/units'} exact>
                        <MainLayout link={'/units'}>
                            <UnitsPage />
                        </MainLayout>
                    </Route>
                    <Route path={'/settings'} exact>
                        <MainLayout link={'/settings'}>
                            <SettingsPage />
                        </MainLayout>
                    </Route>
                    <Route path={'/staff'} exact>
                        <MainLayout link={'/staff'}>
                            <StaffPage />
                        </MainLayout>
                    </Route>
                    <Route path={'/Mapping'} exact>
                        <MainLayout link={'/Mapping'}>
                            <Mapping />
                        </MainLayout>
                    </Route>
                    <Route path={'/workType'} exact>
                        <MainLayout link={'/workType'}>
                            <WorkTypePage />
                        </MainLayout>
                    </Route>
                    <Route path={'/Analytics'} exact>
                        <MainLayout link={'/Analytics'}>
                            <Analytics/>
                        </MainLayout>
                    </Route>
                    <Redirect to={'/'} />
                </Switch>
            </Router>
        </div>
    );
}

export default App;
